var varTemplate = '<p>For attending our conference on Frontend Development.</p>'+'Hope all of you found it informative!!!'+
        '<p>We look forward to see you all in future conferences.</p>'+'<p>Best Regards,</p>'+'<h2>Team UpGrad</h2>';
        document.getElementById('addTemplate').innerHTML=varTemplate;