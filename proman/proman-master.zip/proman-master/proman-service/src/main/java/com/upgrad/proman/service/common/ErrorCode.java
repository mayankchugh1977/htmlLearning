package com.upgrad.proman.service.common;

public interface ErrorCode {
    String getCode();

    String getDefaultMessage();
}
