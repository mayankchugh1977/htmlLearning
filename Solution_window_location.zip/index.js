 We have used a method where there is no need to have extra JS because all of those
actions can be performed in the HTML only
